#!/usr/bin/env python3
"""
Bug Hunter Pro - Automated Vulnerability Discovery and Reporting Tool

A comprehensive tool for security researchers and bug hunters to identify,
exploit, and report vulnerabilities in web applications.

Author: Security Research Team
Version: 1.0.0
"""

import sys
import os
import argparse
from pathlib import Path

# Add src directory to Python path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.main_controller import BugHunterPro
from src.utils.logger import setup_logger
from src.utils.banner import display_banner


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Bug Hunter Pro - Automated Vulnerability Discovery Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '-t', '--target',
        type=str,
        help='Target URL or domain to scan'
    )
    
    parser.add_argument(
        '-s', '--scan-type',
        choices=['quick', 'full', 'custom'],
        default='quick',
        help='Type of vulnerability scan to perform'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        default='reports',
        help='Output directory for reports'
    )
    
    parser.add_argument(
        '-f', '--format',
        choices=['html', 'pdf', 'json', 'markdown'],
        default='html',
        help='Report output format'
    )
    
    parser.add_argument(
        '--gui',
        action='store_true',
        help='Launch graphical user interface'
    )
    
    parser.add_argument(
        '--install-tools',
        action='store_true',
        help='Install required external tools'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose output'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='config/default.yaml',
        help='Configuration file path'
    )
    
    return parser.parse_args()


def main():
    """Main entry point for Bug Hunter Pro."""
    # Display banner
    display_banner()
    
    # Parse arguments
    args = parse_arguments()
    
    # Setup logging
    logger = setup_logger(verbose=args.verbose)
    
    try:
        # Initialize Bug Hunter Pro
        bug_hunter = BugHunterPro(config_path=args.config, logger=logger)
        
        # Handle tool installation
        if args.install_tools:
            logger.info("Installing required tools...")
            bug_hunter.install_tools()
            return
        
        # Launch GUI mode
        if args.gui:
            logger.info("Launching GUI mode...")
            bug_hunter.launch_gui()
            return
        
        # CLI mode - require target
        if not args.target:
            logger.error("Target URL/domain required for CLI mode. Use --gui for GUI mode.")
            sys.exit(1)
        
        # Run vulnerability scan
        logger.info(f"Starting {args.scan_type} scan on {args.target}")
        results = bug_hunter.run_scan(
            target=args.target,
            scan_type=args.scan_type,
            output_dir=args.output,
            output_format=args.format
        )
        
        if results:
            logger.info(f"Scan completed successfully. Results saved to {args.output}")
        else:
            logger.warning("Scan completed with no vulnerabilities found.")
            
    except KeyboardInterrupt:
        logger.info("\nScan interrupted by user.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()

