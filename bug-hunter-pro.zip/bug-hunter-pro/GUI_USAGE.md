# Bug Hunter Pro - Web GUI Usage Guide 🌐

## 🚀 Quick Start

The Bug Hunter Pro Web GUI provides an intuitive interface for conducting vulnerability scans through your web browser.

### **Step 1: Launch the Web Interface**

```bash
# Start the web server
python3 main.py --gui
```

You should see output like:
```
[INFO] Starting web interface on 127.0.0.1:5000
[INFO] Open your browser and go to: http://127.0.0.1:5000
```

### **Step 2: Access the Interface**

Open your web browser and navigate to: **http://127.0.0.1:5000**

## 📱 Web Interface Features

### **🏠 Dashboard (Home Page)**
- **Overview Statistics**: Active scans, total scans, vulnerabilities found
- **Quick Start Links**: Direct access to key features
- **Real-time Status**: Live updates on scan activities
- **Safety Warnings**: Ethical usage reminders

### **🔍 New Scan Page**
Start vulnerability assessments with comprehensive options:

#### **Scan Configuration**
- **Target URL**: Enter the website or domain to scan
  - ✅ Valid: `https://example.com`, `http://testsite.local`
  - ✅ Safe Testing: `httpbin.org`, `testphp.vulnweb.com`

#### **Scan Types**
- **Quick Scan**: Fast assessment (SQL, XSS, Directory enumeration)
- **Full Scan**: Comprehensive testing (SQL, XSS, CSRF, RCE, Directory, SSL)
- **Custom Scan**: User-defined module selection

#### **Output Formats**
- **HTML**: Interactive web-based reports
- **JSON**: Machine-readable data format
- **PDF**: Professional documentation format
- **Markdown**: Documentation-friendly format

#### **Real-time Progress Tracking**
- Live progress bar with percentage completion
- Status updates (starting → running → completed/failed)
- Scan ID for reference
- Direct link to results upon completion

### **📊 Results Page**
- **Scan History**: All completed vulnerability assessments
- **Result Cards**: Summary information for each scan
  - Target URL and scan type
  - Completion status and timestamp
  - Quick access to detailed results
- **Filter and Search**: Find specific scans quickly

### **⚙️ Configuration Page**
- **Current Settings**: View active configuration
- **Scanner Parameters**: Timeout, threads, delays
- **Vulnerability Modules**: Enable/disable specific tests
- **Output Preferences**: Report formats and locations
- **Tool Integration**: External security tool settings

### **ℹ️ About Page**
- **Tool Information**: Version and feature details
- **Usage Guidelines**: Safety and legal considerations
- **Feature Overview**: Complete capability listing

## 🛠️ Advanced Usage

### **API Access**
The web interface provides RESTful API endpoints:

```bash
# Start a scan programmatically
curl -X POST http://127.0.0.1:5000/api/scan \
  -H "Content-Type: application/json" \
  -d '{
    "target": "httpbin.org",
    "scan_type": "quick",
    "output_format": "json"
  }'

# Check scan status
curl http://127.0.0.1:5000/api/scan/{scan_id}/status

# Get results
curl http://127.0.0.1:5000/api/results/{scan_id}
```

### **Available API Endpoints**

| Endpoint | Method | Purpose |
|----------|--------|----------|
| `/api/scan` | POST | Start new vulnerability scan |
| `/api/scan/{id}/status` | GET | Get scan progress and status |
| `/api/results/{id}` | GET | Retrieve detailed scan results |
| `/api/config` | GET/POST | View/update configuration |

## 🧪 Testing the Web Interface

Use the provided test script to verify functionality:

```bash
# Show usage instructions
python3 test_web_gui.py --usage

# Run automated tests (requires GUI to be running)
python3 test_web_gui.py --test
```

### **Safe Testing Targets**

Always use authorized targets for testing:

- **httpbin.org** - HTTP testing service
- **testphp.vulnweb.com** - Intentionally vulnerable application
- **Your own local applications**
- **Dedicated testing environments**

## 💡 Best Practices

### **Security Considerations**
1. **Authorization First**: Only scan systems you own or have explicit permission to test
2. **Network Isolation**: Run scans in isolated environments when possible
3. **Rate Limiting**: Use appropriate delays to avoid overwhelming targets
4. **Documentation**: Keep records of authorized scanning activities

### **Performance Optimization**
1. **Resource Management**: Monitor system resources during large scans
2. **Concurrent Limits**: Adjust thread counts based on target capacity
3. **Scan Scheduling**: Perform comprehensive scans during off-peak hours
4. **Result Storage**: Regularly archive old scan results

### **Workflow Integration**
1. **Regular Assessments**: Schedule periodic vulnerability scans
2. **Change Detection**: Scan after significant application updates
3. **Report Distribution**: Share findings with development teams
4. **Remediation Tracking**: Follow up on identified vulnerabilities

## 🎯 Common Use Cases

### **Development Team Integration**
```bash
# Quick security check during development
python3 main.py -t http://localhost:3000 -s quick

# Comprehensive pre-production assessment
python3 main.py -t https://staging.example.com -s full -f pdf
```

### **Security Team Workflows**
```bash
# Automated scanning with custom configuration
python3 main.py -t https://app.company.com -s custom --config security_config.yaml

# API integration for continuous monitoring
curl -X POST http://127.0.0.1:5000/api/scan -d '{"target":"internal.app","scan_type":"full"}'
```

### **Educational Usage**
```bash
# Learning vulnerability assessment
python3 main.py -t testphp.vulnweb.com -v

# Understanding different scan types
python3 main.py -t httpbin.org -s full -f json
```

## 🔧 Troubleshooting

### **Common Issues**

**Web Interface Won't Start**
```bash
# Check if port 5000 is available
sudo netstat -tlnp | grep :5000

# Use different port if needed
# Edit config/default.yaml:
web_interface:
  port: 8080
```

**Scans Not Starting**
- Verify target URL format
- Check network connectivity
- Review configuration settings
- Monitor log output for errors

**Missing Dependencies**
```bash
# Install missing packages
pip3 install -r requirements.txt

# Install system tools
python3 main.py --install-tools
```

### **Log Analysis**
Monitor logs for detailed error information:
```bash
# View real-time logs
tail -f logs/bug_hunter.log

# Search for specific errors
grep "ERROR" logs/bug_hunter.log
```

## 📞 Support and Resources

- **Documentation**: Check `README.md` for comprehensive information
- **Configuration**: Review `config/default.yaml` for all settings
- **Issues**: Report problems via project issue tracker
- **Community**: Join discussions for tips and best practices

---

**⚠️ Legal Reminder**: Bug Hunter Pro is designed for educational purposes and authorized security testing only. Always ensure you have proper permission before scanning any target system. Unauthorized vulnerability scanning may be illegal and unethical.

