"""
Main Controller for Bug Hunter Pro

This module contains the main controller class that orchestrates all
vulnerability scanning, exploitation, and reporting activities.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any

from ..scanners.vulnerability_scanner import VulnerabilityScanner
from ..exploits.exploit_manager import ExploitManager
from ..reports.report_generator import ReportGenerator
from ..tools.tool_installer import ToolInstaller
from ..gui.web_interface import WebInterface
from ..utils.config_manager import ConfigManager
from ..utils.database import DatabaseManager


class BugHunterPro:
    """Main controller class for Bug Hunter Pro application."""
    
    def __init__(self, config_path: str = None, logger=None):
        """Initialize Bug Hunter Pro with configuration and logger."""
        self.logger = logger
        self.config_manager = ConfigManager(config_path)
        self.config = self.config_manager.get_config()
        
        # Initialize core components
        self.db_manager = DatabaseManager(self.config.get('database', {}))
        self.scanner = VulnerabilityScanner(self.config, self.logger)
        self.exploit_manager = ExploitManager(self.config, self.logger)
        self.report_generator = ReportGenerator(self.config, self.logger)
        self.tool_installer = ToolInstaller(self.config, self.logger)
        self.web_interface = WebInterface(self.config, self.logger)
        
        self.logger.info("Bug Hunter Pro initialized successfully")
    
    def run_scan(self, target: str, scan_type: str = 'quick', 
                 output_dir: str = 'reports', output_format: str = 'html') -> Dict[str, Any]:
        """Run vulnerability scan on target."""
        self.logger.info(f"Starting {scan_type} scan on {target}")
        
        try:
            # Validate target
            if not self._validate_target(target):
                raise ValueError(f"Invalid target: {target}")
            
            # Create scan session
            scan_id = self.db_manager.create_scan_session(target, scan_type)
            
            # Run vulnerability scan
            scan_results = self.scanner.scan_target(
                target=target,
                scan_type=scan_type,
                scan_id=scan_id
            )
            
            # Process vulnerabilities found
            if scan_results.get('vulnerabilities'):
                self.logger.info(f"Found {len(scan_results['vulnerabilities'])} vulnerabilities")
                
                # Generate PoCs for high-severity vulnerabilities
                for vuln in scan_results['vulnerabilities']:
                    if vuln.get('severity') in ['high', 'critical']:
                        poc = self.exploit_manager.generate_poc(vuln)
                        if poc:
                            vuln['poc'] = poc
            
            # Generate report
            report_path = self.report_generator.generate_report(
                scan_results=scan_results,
                output_dir=output_dir,
                output_format=output_format,
                scan_id=scan_id
            )
            
            # Update database with results
            self.db_manager.update_scan_results(scan_id, scan_results, report_path)
            
            self.logger.info(f"Scan completed. Report saved to: {report_path}")
            return {
                'scan_id': scan_id,
                'vulnerabilities_found': len(scan_results.get('vulnerabilities', [])),
                'report_path': report_path,
                'results': scan_results
            }
            
        except Exception as e:
            self.logger.error(f"Scan failed: {str(e)}")
            raise
    
    def install_tools(self) -> bool:
        """Install required external tools."""
        self.logger.info("Installing required tools...")
        try:
            return self.tool_installer.install_all_tools()
        except Exception as e:
            self.logger.error(f"Tool installation failed: {str(e)}")
            return False
    
    def launch_gui(self) -> None:
        """Launch web-based GUI interface."""
        self.logger.info("Launching web interface...")
        try:
            self.web_interface.run()
        except Exception as e:
            self.logger.error(f"Failed to launch GUI: {str(e)}")
            raise
    
    def get_scan_history(self) -> List[Dict[str, Any]]:
        """Get scan history from database."""
        return self.db_manager.get_scan_history()
    
    def get_scan_results(self, scan_id: str) -> Dict[str, Any]:
        """Get specific scan results."""
        return self.db_manager.get_scan_results(scan_id)
    
    def export_scan_results(self, scan_id: str, export_format: str, 
                          output_path: str) -> str:
        """Export scan results in specified format."""
        scan_results = self.get_scan_results(scan_id)
        return self.report_generator.export_results(
            scan_results, export_format, output_path
        )
    
    def _validate_target(self, target: str) -> bool:
        """Validate target URL or domain."""
        import re
        from urllib.parse import urlparse
        
        # Check if it's a valid URL
        try:
            result = urlparse(target)
            if result.scheme and result.netloc:
                return True
        except:
            pass
        
        # Check if it's a valid domain/IP
        domain_pattern = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)'
        ip_pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
        
        if re.match(domain_pattern, target) or re.match(ip_pattern, target):
            return True
        
        return False
    
    def shutdown(self):
        """Gracefully shutdown Bug Hunter Pro."""
        self.logger.info("Shutting down Bug Hunter Pro...")
        if hasattr(self, 'db_manager'):
            self.db_manager.close()
        self.logger.info("Shutdown complete")

