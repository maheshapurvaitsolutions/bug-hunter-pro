import os
import json
import threading
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from werkzeug.utils import secure_filename
from pathlib import Path


class WebInterface:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        # Get the project root directory
        project_root = Path(__file__).parent.parent.parent
        template_folder = project_root / 'templates'
        static_folder = project_root / 'static'
        
        self.app = Flask(__name__, 
                         template_folder=str(template_folder), 
                         static_folder=str(static_folder))
        self.app.secret_key = config.get('web_interface', {}).get('secret_key', 'dev-key-change-this')
        
        # Store for active scans
        self.active_scans = {}
        self.scan_results = {}
        
        # Setup routes
        self._setup_routes()
        
        # Create templates directory if it doesn't exist
        template_dir = Path(self.app.template_folder)
        template_dir.mkdir(parents=True, exist_ok=True)
        
        static_dir = Path(self.app.static_folder)
        static_dir.mkdir(parents=True, exist_ok=True)
    
    def _setup_routes(self):
        """Setup Flask routes."""
        
        @self.app.route('/')
        def index():
            """Main dashboard."""
            # Calculate vulnerability statistics
            total_vulnerabilities = 0
            recent_vulnerabilities = []
            
            for scan_result in self.scan_results.values():
                if scan_result.get('results') and scan_result['results'].get('vulnerabilities'):
                    vulns = scan_result['results']['vulnerabilities']
                    total_vulnerabilities += len(vulns)
                    recent_vulnerabilities.extend(vulns)
            
            # Sort by severity (high priority first)
            severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4, 'unknown': 5}
            recent_vulnerabilities.sort(key=lambda x: severity_order.get(x.get('severity', 'unknown').lower(), 5))
            
            return render_template('index.html', 
                                 active_scans=len(self.active_scans),
                                 total_scans=len(self.scan_results),
                                 total_vulnerabilities=total_vulnerabilities,
                                 recent_vulnerabilities=recent_vulnerabilities[:5])
        
        @self.app.route('/scan')
        def scan_page():
            """Scan configuration page."""
            return render_template('scan.html')
        
        @self.app.route('/api/scan', methods=['POST'])
        def start_scan():
            """Start a new vulnerability scan."""
            try:
                data = request.get_json()
                target = data.get('target')
                scan_type = data.get('scan_type', 'quick')
                output_format = data.get('output_format', 'html')
                
                if not target:
                    return jsonify({'error': 'Target URL is required'}), 400
                
                # Generate scan ID
                scan_id = f"web_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                
                # Store scan info
                self.active_scans[scan_id] = {
                    'target': target,
                    'scan_type': scan_type,
                    'output_format': output_format,
                    'status': 'starting',
                    'start_time': datetime.now().isoformat(),
                    'progress': 0
                }
                
                # Start scan in background thread
                thread = threading.Thread(
                    target=self._run_background_scan,
                    args=(scan_id, target, scan_type, output_format)
                )
                thread.daemon = True
                thread.start()
                
                return jsonify({
                    'success': True,
                    'scan_id': scan_id,
                    'message': 'Scan started successfully'
                })
                
            except Exception as e:
                self.logger.error(f"Error starting scan: {str(e)}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/scan/<scan_id>/status')
        def scan_status(scan_id):
            """Get scan status."""
            if scan_id in self.active_scans:
                return jsonify(self.active_scans[scan_id])
            elif scan_id in self.scan_results:
                return jsonify(self.scan_results[scan_id])
            else:
                return jsonify({'error': 'Scan not found'}), 404
        
        @self.app.route('/results')
        def results_page():
            """Scan results page."""
            return render_template('results.html', scan_results=self.scan_results)
        
        @self.app.route('/api/results/<scan_id>')
        def get_results(scan_id):
            """Get detailed scan results."""
            if scan_id in self.scan_results:
                return jsonify(self.scan_results[scan_id])
            else:
                return jsonify({'error': 'Results not found'}), 404
        
        @self.app.route('/config')
        def config_page():
            """Configuration page."""
            return render_template('config.html', config=self.config)
        
        @self.app.route('/api/config', methods=['GET', 'POST'])
        def handle_config():
            """Handle configuration updates."""
            if request.method == 'GET':
                return jsonify(self.config)
            else:
                try:
                    new_config = request.get_json()
                    # Update configuration (simplified)
                    self.config.update(new_config)
                    return jsonify({'success': True, 'message': 'Configuration updated'})
                except Exception as e:
                    return jsonify({'error': str(e)}), 500
        
        @self.app.route('/about')
        def about_page():
            """About page."""
            return render_template('about.html')
        
        @self.app.errorhandler(404)
        def not_found(error):
            return render_template('404.html'), 404
        
        @self.app.errorhandler(500)
        def internal_error(error):
            return render_template('500.html'), 500
    
    def _run_background_scan(self, scan_id, target, scan_type, output_format):
        """Run scan in background thread."""
        try:
            # Update status
            self.active_scans[scan_id]['status'] = 'running'
            self.active_scans[scan_id]['progress'] = 25
            
            # Import the main controller here to avoid circular imports
            from ..core.main_controller import BugHunterPro
            
            # Create scanner instance
            scanner = BugHunterPro(logger=self.logger)
            
            # Update progress
            self.active_scans[scan_id]['progress'] = 50
            
            # Run the scan
            results = scanner.run_scan(
                target=target,
                scan_type=scan_type,
                output_dir='reports',
                output_format=output_format
            )
            
            # Update progress
            self.active_scans[scan_id]['progress'] = 100
            self.active_scans[scan_id]['status'] = 'completed'
            self.active_scans[scan_id]['end_time'] = datetime.now().isoformat()
            
            # Move to results
            self.scan_results[scan_id] = self.active_scans[scan_id]
            self.scan_results[scan_id]['results'] = results
            
            # Remove from active scans
            del self.active_scans[scan_id]
            
            self.logger.info(f"Web scan {scan_id} completed successfully")
            
        except Exception as e:
            self.logger.error(f"Background scan failed: {str(e)}")
            
            # Update status to failed
            if scan_id in self.active_scans:
                self.active_scans[scan_id]['status'] = 'failed'
                self.active_scans[scan_id]['error'] = str(e)
                self.active_scans[scan_id]['end_time'] = datetime.now().isoformat()
    
    def run(self):
        """Run the Flask web interface."""
        web_config = self.config.get('web_interface', {})
        host = web_config.get('host', '127.0.0.1')
        port = web_config.get('port', 5000)
        debug = web_config.get('debug', False)
        
        # Create templates if they don't exist
        self._create_templates()
        
        self.logger.info(f"Starting web interface on {host}:{port}")
        self.logger.info(f"Open your browser and go to: http://{host}:{port}")
        
        self.app.run(host=host, port=port, debug=debug)
    
    def _create_templates(self):
        """Create basic HTML templates."""
        template_dir = Path(self.app.template_folder)
        
        # Base template
        base_template = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Bug Hunter Pro{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .scan-card {
            transition: transform 0.2s;
        }
        .scan-card:hover {
            transform: translateY(-5px);
        }
        .vulnerability-badge {
            font-size: 0.8em;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center text-white mb-4">
                        <h4><i class="fas fa-bug"></i> Bug Hunter Pro</h4>
                    </div>
                    <ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item">
                            <a href="{{ url_for('index') }}" class="nav-link text-white">
                                <i class="fas fa-dashboard"></i> Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="{{ url_for('scan_page') }}" class="nav-link text-white">
                                <i class="fas fa-search"></i> New Scan
                            </a>
                        </li>
                        <li>
                            <a href="{{ url_for('results_page') }}" class="nav-link text-white">
                                <i class="fas fa-chart-bar"></i> Results
                            </a>
                        </li>
                        <li>
                            <a href="{{ url_for('config_page') }}" class="nav-link text-white">
                                <i class="fas fa-cog"></i> Configuration
                            </a>
                        </li>
                        <li>
                            <a href="{{ url_for('about_page') }}" class="nav-link text-white">
                                <i class="fas fa-info-circle"></i> About
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                {% block content %}{% endblock %}
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
        '''
        
        # Main dashboard
        index_template = '''
{% extends "base.html" %}

{% block title %}Dashboard - Bug Hunter Pro{% endblock %}

{% block content %}
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-dashboard"></i> Dashboard</h1>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card scan-card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Active Scans</h5>
                        <h2>{{ active_scans }}</h2>
                    </div>
                    <i class="fas fa-spinner fa-2x"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card scan-card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Total Scans</h5>
                        <h2>{{ total_scans }}</h2>
                    </div>
                    <i class="fas fa-check-circle fa-2x"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card scan-card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Vulnerabilities</h5>
                        <h2>0</h2>
                    </div>
                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-rocket"></i> Quick Start</h5>
            </div>
            <div class="card-body">
                <p>Welcome to Bug Hunter Pro Web Interface! Get started by:</p>
                <div class="row">
                    <div class="col-md-6">
                        <div class="list-group">
                            <a href="{{ url_for('scan_page') }}" class="list-group-item list-group-item-action">
                                <i class="fas fa-play-circle text-primary"></i>
                                <strong>Start New Scan</strong>
                                <p class="mb-1">Begin vulnerability assessment on a target</p>
                            </a>
                            <a href="{{ url_for('results_page') }}" class="list-group-item list-group-item-action">
                                <i class="fas fa-chart-line text-success"></i>
                                <strong>View Results</strong>
                                <p class="mb-1">Review completed scan reports</p>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>Important:</strong> Only scan targets you own or have explicit permission to test.
                            Unauthorized scanning is illegal and unethical.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
        '''
        
        # Scan page
        scan_template = '''
{% extends "base.html" %}

{% block title %}New Scan - Bug Hunter Pro{% endblock %}

{% block content %}
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-search"></i> New Vulnerability Scan</h1>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-cog"></i> Scan Configuration</h5>
            </div>
            <div class="card-body">
                <form id="scanForm">
                    <div class="mb-3">
                        <label for="target" class="form-label">Target URL</label>
                        <input type="url" class="form-control" id="target" placeholder="https://example.com" required>
                        <div class="form-text">Enter the URL or domain to scan</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="scanType" class="form-label">Scan Type</label>
                        <select class="form-select" id="scanType">
                            <option value="quick">Quick Scan (Fast, basic checks)</option>
                            <option value="full">Full Scan (Comprehensive assessment)</option>
                            <option value="custom">Custom Scan (User-defined modules)</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="outputFormat" class="form-label">Report Format</label>
                        <select class="form-select" id="outputFormat">
                            <option value="html">HTML Report</option>
                            <option value="json">JSON Data</option>
                            <option value="pdf">PDF Document</option>
                            <option value="markdown">Markdown</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-play"></i> Start Scan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-info-circle"></i> Scan Information</h5>
            </div>
            <div class="card-body">
                <h6>Scan Types:</h6>
                <ul class="list-unstyled">
                    <li><strong>Quick:</strong> SQL, XSS, Directory</li>
                    <li><strong>Full:</strong> SQL, XSS, CSRF, RCE, Directory, SSL</li>
                    <li><strong>Custom:</strong> User-defined modules</li>
                </ul>
                
                <h6 class="mt-3">Safety Notice:</h6>
                <div class="alert alert-warning alert-sm">
                    <small>
                        <i class="fas fa-shield-alt"></i>
                        Only scan targets you own or have permission to test.
                    </small>
                </div>
            </div>
        </div>
        
        <!-- Scan Progress (hidden by default) -->
        <div class="card mt-3" id="progressCard" style="display: none;">
            <div class="card-header">
                <h5><i class="fas fa-clock"></i> Scan Progress</h5>
            </div>
            <div class="card-body">
                <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: 0%" id="progressBar"></div>
                </div>
                <p id="progressText">Initializing scan...</p>
                <p><strong>Scan ID:</strong> <span id="scanId"></span></p>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}
<script>
$(document).ready(function() {
    $('#scanForm').on('submit', function(e) {
        e.preventDefault();
        
        const target = $('#target').val();
        const scanType = $('#scanType').val();
        const outputFormat = $('#outputFormat').val();
        
        // Show progress card
        $('#progressCard').show();
        
        // Start scan
        $.ajax({
            url: '/api/scan',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                target: target,
                scan_type: scanType,
                output_format: outputFormat
            }),
            success: function(response) {
                if (response.success) {
                    $('#scanId').text(response.scan_id);
                    monitorScan(response.scan_id);
                } else {
                    alert('Error: ' + response.error);
                }
            },
            error: function(xhr) {
                alert('Error starting scan: ' + xhr.responseJSON.error);
            }
        });
    });
    
    function monitorScan(scanId) {
        const interval = setInterval(function() {
            $.ajax({
                url: '/api/scan/' + scanId + '/status',
                success: function(status) {
                    $('#progressBar').css('width', status.progress + '%');
                    $('#progressText').text('Status: ' + status.status);
                    
                    if (status.status === 'completed') {
                        clearInterval(interval);
                        $('#progressText').html('<span class="text-success">Scan completed! <a href="/results">View Results</a></span>');
                    } else if (status.status === 'failed') {
                        clearInterval(interval);
                        $('#progressText').html('<span class="text-danger">Scan failed: ' + (status.error || 'Unknown error') + '</span>');
                    }
                }
            });
        }, 2000);
    }
});
</script>
{% endblock %}
        '''
        
        # Write templates
        with open(template_dir / 'base.html', 'w') as f:
            f.write(base_template)
        
        with open(template_dir / 'index.html', 'w') as f:
            f.write(index_template)
        
        with open(template_dir / 'scan.html', 'w') as f:
            f.write(scan_template)
        
        # Simple results template
        results_template = '''
{% extends "base.html" %}
{% block title %}Results - Bug Hunter Pro{% endblock %}
{% block content %}
<h1><i class="fas fa-chart-bar"></i> Scan Results</h1>
<div class="row">
    {% if scan_results %}
        {% for scan_id, result in scan_results.items() %}
        <div class="col-md-6 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5>{{ result.target }}</h5>
                    <p>Type: {{ result.scan_type }}</p>
                    <p>Status: <span class="badge bg-success">{{ result.status }}</span></p>
                    <p>Time: {{ result.start_time }}</p>
                </div>
            </div>
        </div>
        {% endfor %}
    {% else %}
        <div class="col-12">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No scan results available yet.
            </div>
        </div>
    {% endif %}
</div>
{% endblock %}
        '''
        
        with open(template_dir / 'results.html', 'w') as f:
            f.write(results_template)
        
        # Simple about template
        about_template = '''
{% extends "base.html" %}
{% block title %}About - Bug Hunter Pro{% endblock %}
{% block content %}
<h1><i class="fas fa-info-circle"></i> About Bug Hunter Pro</h1>
<div class="card">
    <div class="card-body">
        <h5>Bug Hunter Pro v1.0.0</h5>
        <p>Automated Vulnerability Discovery and Reporting Tool</p>
        <p><strong>Features:</strong></p>
        <ul>
            <li>SQL Injection Detection</li>
            <li>Cross-Site Scripting (XSS) Testing</li>
            <li>CSRF Vulnerability Assessment</li>
            <li>Remote Code Execution (RCE) Detection</li>
            <li>Directory Enumeration</li>
            <li>SSL/TLS Security Analysis</li>
        </ul>
        <div class="alert alert-warning">
            <strong>Important:</strong> This tool is for educational and authorized security testing only.
        </div>
    </div>
</div>
{% endblock %}
        '''
        
        with open(template_dir / 'about.html', 'w') as f:
            f.write(about_template)
        
        # Simple config template
        config_template = '''
{% extends "base.html" %}
{% block title %}Configuration - Bug Hunter Pro{% endblock %}
{% block content %}
<h1><i class="fas fa-cog"></i> Configuration</h1>
<div class="card">
    <div class="card-body">
        <p>Configuration management interface (coming soon)</p>
        <pre>{{ config | tojson(indent=2) }}</pre>
    </div>
</div>
{% endblock %}
        '''
        
        with open(template_dir / 'config.html', 'w') as f:
            f.write(config_template)

