"""
SQL Injection Scanner Module

This module contains SQL injection detection functionality.
"""

import re
import time
from typing import Dict, List, Any, Optional
from urllib.parse import urljoin, urlparse, parse_qs


class SQLInjectionScanner:
    """SQL Injection vulnerability scanner."""
    
    def __init__(self, config: Dict[str, Any], logger):
        """Initialize SQL injection scanner."""
        self.config = config.get('sql_injection', {})
        self.logger = logger
        self.error_patterns = self.config.get('error_patterns', [])
        self.time_delay = self.config.get('time_based_delay', 5)
        
    def scan(self, target: str, recon_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Scan target for SQL injection vulnerabilities."""
        vulnerabilities = []
        
        # Basic SQL injection payloads
        sql_payloads = [
            "'",
            "' OR '1'='1",
            "' OR 1=1--",
            "'; DROP TABLE users;--",
            "' UNION SELECT null--",
            "1' AND SLEEP(5)--"
        ]
        
        # Test forms
        forms = recon_data.get('forms', [])
        for form in forms:
            for payload in sql_payloads:
                vuln = self._test_form_sql_injection(target, form, payload)
                if vuln:
                    vulnerabilities.append(vuln)
        
        # Test URL parameters
        if '?' in target:
            for payload in sql_payloads:
                vuln = self._test_url_sql_injection(target, payload)
                if vuln:
                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _test_form_sql_injection(self, target: str, form: Dict[str, Any], payload: str) -> Optional[Dict[str, Any]]:
        """Test form for SQL injection - REAL IMPLEMENTATION."""
        import requests
        from ..utils.http_client import HTTPClient
        
        try:
            form_url = form.get('action', target)
            if not form_url.startswith(('http://', 'https://')):
                form_url = urljoin(target, form_url)
            
            # Prepare form data with SQL injection payload
            form_data = {}
            for input_field in form.get('inputs', []):
                field_name = input_field.get('name', '')
                if field_name:
                    if input_field.get('type') == 'password':
                        form_data[field_name] = payload
                    else:
                        form_data[field_name] = payload
            
            if not form_data:
                return None
            
            self.logger.debug(f"Testing SQL injection on form: {form_url} with payload: {payload[:20]}...")
            
            # Send request with payload
            method = form.get('method', 'GET').upper()
            if method == 'POST':
                response = requests.post(form_url, data=form_data, timeout=10, verify=False)
            else:
                response = requests.get(form_url, params=form_data, timeout=10, verify=False)
            
            # Check for SQL error patterns in response
            response_text = response.text.lower()
            for error_pattern in self.error_patterns:
                if error_pattern.lower() in response_text:
                    return {
                        'type': 'SQL Injection',
                        'severity': 'high',
                        'url': form_url,
                        'parameter': list(form_data.keys())[0],
                        'payload': payload,
                        'description': f'SQL injection vulnerability detected in form. Database error pattern found: {error_pattern}',
                        'evidence': f'Error pattern "{error_pattern}" detected in response with payload: {payload}',
                        'remediation': 'Use parameterized queries and input validation',
                        'http_method': method,
                        'response_length': len(response.text)
                    }
            
            # Check for common SQL error strings
            sql_errors = [
                'mysql_fetch_array', 'mysql_num_rows', 'mysql_fetch_assoc',
                'ora-01756', 'oracle driver', 'ora-00933',
                'microsoft ole db', 'odbc driver', 'sql server',
                'sqlite_master', 'sqlite error',
                'postgresql', 'psql:', 'pg_',
                'you have an error in your sql syntax',
                'syntax error', 'unterminated quoted string',
                'unexpected end of sql command',
                'warning: mysql_', 'function.mysql',
                'quoted string not properly terminated'
            ]
            
            for error in sql_errors:
                if error in response_text:
                    return {
                        'type': 'SQL Injection',
                        'severity': 'high',
                        'url': form_url,
                        'parameter': list(form_data.keys())[0],
                        'payload': payload,
                        'description': f'SQL injection vulnerability detected. Database error: {error}',
                        'evidence': f'SQL error "{error}" found in response',
                        'remediation': 'Use parameterized queries and proper input validation',
                        'http_method': method,
                        'response_length': len(response.text)
                    }
            
        except Exception as e:
            self.logger.error(f"Error testing form SQL injection: {str(e)}")
        
        return None
    
    def _test_url_sql_injection(self, target: str, payload: str) -> Optional[Dict[str, Any]]:
        """Test URL parameters for SQL injection - REAL IMPLEMENTATION."""
        import requests
        
        try:
            parsed_url = urlparse(target)
            params = parse_qs(parsed_url.query)
            
            if not params:
                return None
            
            # Test each parameter
            for param_name, param_values in params.items():
                if not param_values:
                    continue
                
                # Create test URL with SQL injection payload
                test_params = params.copy()
                test_params[param_name] = [payload]
                
                # Reconstruct URL with malicious parameter
                test_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
                param_string = '&'.join([f"{k}={v[0]}" for k, v in test_params.items()])
                if param_string:
                    test_url += f"?{param_string}"
                
                self.logger.debug(f"Testing SQL injection on URL: {test_url[:100]}...")
                
                # Send request
                response = requests.get(test_url, timeout=10, verify=False)
                response_text = response.text.lower()
                
                # Check for SQL error patterns
                sql_errors = [
                    'mysql_fetch_array', 'mysql_num_rows', 'mysql_fetch_assoc',
                    'ora-01756', 'oracle driver', 'ora-00933',
                    'microsoft ole db', 'odbc driver', 'sql server',
                    'sqlite_master', 'sqlite error',
                    'postgresql', 'psql:', 'pg_',
                    'you have an error in your sql syntax',
                    'syntax error', 'unterminated quoted string',
                    'unexpected end of sql command',
                    'warning: mysql_', 'function.mysql',
                    'quoted string not properly terminated',
                    'mysql_connect()', 'mysql_select_db()'
                ]
                
                for error in sql_errors:
                    if error in response_text:
                        return {
                            'type': 'SQL Injection',
                            'severity': 'high',
                            'url': target,
                            'parameter': param_name,
                            'payload': payload,
                            'description': f'SQL injection vulnerability detected in URL parameter "{param_name}"',
                            'evidence': f'SQL error "{error}" found in response',
                            'remediation': 'Use parameterized queries and proper input validation',
                            'vulnerable_url': test_url,
                            'response_length': len(response.text)
                        }
                
                # Check for configuration error patterns
                for error_pattern in self.error_patterns:
                    if error_pattern.lower() in response_text:
                        return {
                            'type': 'SQL Injection',
                            'severity': 'high', 
                            'url': target,
                            'parameter': param_name,
                            'payload': payload,
                            'description': f'SQL injection vulnerability detected in parameter "{param_name}"',
                            'evidence': f'Database error pattern "{error_pattern}" detected',
                            'remediation': 'Implement proper input validation and use parameterized queries',
                            'vulnerable_url': test_url,
                            'response_length': len(response.text)
                        }
                        
        except Exception as e:
            self.logger.error(f"Error testing URL SQL injection: {str(e)}")
        
        return None

