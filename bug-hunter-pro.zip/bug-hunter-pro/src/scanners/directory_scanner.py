import requests
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin, urlparse
from typing import Dict, List, Any, Optional


class DirectoryScanner:
    """Directory and file enumeration scanner."""
    
    def __init__(self, config, logger):
        self.config = config.get('directory_bruteforce', {})
        self.logger = logger
        self.wordlist = self._get_default_wordlist()
        self.extensions = self.config.get('extensions', ['.php', '.html', '.asp', '.aspx', '.jsp'])
        self.status_codes = self.config.get('status_codes', [200, 301, 302, 403])
        
    def scan(self, target: str, recon_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Scan target for hidden directories and files."""
        vulnerabilities = []
        
        self.logger.info(f"Starting directory enumeration on {target}")
        
        # Test common directories and files
        found_paths = self._bruteforce_directories(target)
        
        for path_info in found_paths:
            # Check if this reveals sensitive information
            severity = self._assess_path_severity(path_info)
            
            if severity != 'info':  # Only report medium+ findings
                vulnerabilities.append({
                    'type': 'Directory/File Disclosure',
                    'severity': severity,
                    'url': path_info['url'],
                    'parameter': 'path',
                    'payload': path_info['path'],
                    'description': f'Accessible {path_info["type"]} found: {path_info["path"]}',
                    'evidence': f'HTTP {path_info["status_code"]} response for {path_info["url"]}',
                    'remediation': 'Review file permissions and consider restricting access to sensitive directories',
                    'status_code': path_info['status_code'],
                    'content_length': path_info['content_length']
                })
        
        return vulnerabilities
    
    def _get_default_wordlist(self) -> List[str]:
        """Get default directory/file wordlist."""
        return [
            # Common directories
            'admin', 'administrator', 'login', 'panel', 'control',
            'dashboard', 'config', 'configuration', 'settings',
            'backup', 'backups', 'old', 'test', 'testing',
            'dev', 'development', 'staging', 'tmp', 'temp',
            'uploads', 'upload', 'files', 'documents', 'docs',
            'images', 'img', 'css', 'js', 'scripts',
            'includes', 'inc', 'lib', 'library', 'vendor',
            'api', 'v1', 'v2', 'rest', 'json',
            'database', 'db', 'mysql', 'sql',
            'log', 'logs', 'debug', 'error',
            'wp-admin', 'wp-content', 'wp-includes',
            'phpmyadmin', 'pma', 'mysql',
            'secure', 'private', 'protected',
            'users', 'user', 'profile', 'account',
            
            # Common files
            'robots.txt', 'sitemap.xml', '.htaccess', '.htpasswd',
            'web.config', 'config.php', 'configuration.php',
            'settings.php', 'database.php', 'db.php',
            'admin.php', 'login.php', 'index.php',
            'backup.sql', 'dump.sql', 'database.sql',
            'readme.txt', 'README.md', 'changelog.txt',
            'version.txt', 'VERSION', '.env', '.git',
            'phpinfo.php', 'info.php', 'test.php'
        ]
    
    def _bruteforce_directories(self, target: str) -> List[Dict[str, Any]]:
        """Bruteforce directories and files."""
        found_paths = []
        base_url = target.rstrip('/')
        
        # Prepare list of paths to test
        paths_to_test = []
        
        # Add direct paths
        for word in self.wordlist:
            paths_to_test.append(word)
            
            # Add with extensions if it doesn't already have one
            if '.' not in word:
                for ext in self.extensions:
                    paths_to_test.append(f"{word}{ext}")
        
        # Test paths concurrently
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_path = {}
            
            for path in paths_to_test[:50]:  # Limit to 50 requests for demo
                test_url = f"{base_url}/{path}"
                future = executor.submit(self._test_path, test_url, path)
                future_to_path[future] = path
            
            # Collect results
            for future in as_completed(future_to_path):
                path = future_to_path[future]
                try:
                    result = future.result()
                    if result:
                        found_paths.append(result)
                except Exception as e:
                    self.logger.debug(f"Error testing path {path}: {str(e)}")
        
        return found_paths
    
    def _test_path(self, url: str, path: str) -> Optional[Dict[str, Any]]:
        """Test a single path for accessibility."""
        try:
            response = requests.get(url, timeout=10, verify=False, allow_redirects=False)
            
            if response.status_code in self.status_codes:
                return {
                    'url': url,
                    'path': path,
                    'status_code': response.status_code,
                    'content_length': len(response.content),
                    'type': 'file' if '.' in path else 'directory'
                }
                
        except Exception as e:
            self.logger.debug(f"Error accessing {url}: {str(e)}")
        
        return None
    
    def _assess_path_severity(self, path_info: Dict[str, Any]) -> str:
        """Assess the security severity of a found path."""
        path = path_info['path'].lower()
        
        # High severity - sensitive files/directories
        high_risk_patterns = [
            'admin', 'config', 'backup', 'database', 'db',
            '.htaccess', '.htpasswd', '.env', 'web.config',
            'phpinfo', 'phpmyadmin', 'wp-admin',
            'private', 'secure', 'protected'
        ]
        
        for pattern in high_risk_patterns:
            if pattern in path:
                return 'high'
        
        # Medium severity - potentially sensitive
        medium_risk_patterns = [
            'test', 'dev', 'staging', 'tmp', 'temp',
            'upload', 'log', 'error', 'debug',
            'api', 'json', 'xml'
        ]
        
        for pattern in medium_risk_patterns:
            if pattern in path:
                return 'medium'
        
        # Check status code
        if path_info['status_code'] == 403:
            return 'medium'  # Forbidden but exists
        
        return 'info'

