"""
Configuration Manager for Bug Hunter Pro

This module handles loading and managing configuration settings.
"""

import yaml
import os
from pathlib import Path
from typing import Dict, Any, Optional


class ConfigManager:
    """Configuration manager for Bug Hunter Pro."""
    
    def __init__(self, config_path: str = None):
        """Initialize configuration manager."""
        self.config_path = config_path or 'config/default.yaml'
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default."""
        config_file = Path(self.config_path)
        
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    return yaml.safe_load(f) or {}
            except Exception as e:
                print(f"Error loading config: {e}")
                return self._get_default_config()
        else:
            # Create default config file
            default_config = self._get_default_config()
            self._save_config(default_config)
            return default_config
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration settings."""
        return {
            'scanner': {
                'timeout': 30,
                'max_threads': 10,
                'delay_between_requests': 0.1,
                'user_agent': 'BugHunterPro/1.0',
                'follow_redirects': True,
                'max_redirects': 5,
                'verify_ssl': False,
                'custom_headers': {},
                'proxy': None
            },
            'sql_injection': {
                'payloads_file': 'payloads/sql_payloads.txt',
                'error_patterns': [
                    'mysql_fetch_array',
                    'ORA-01756',
                    'Microsoft OLE DB',
                    'SQLite/JDBCDriver',
                    'PostgreSQL query failed'
                ],
                'blind_techniques': True,
                'time_based_delay': 5
            },
            'xss': {
                'payloads_file': 'payloads/xss_payloads.txt',
                'reflection_patterns': [
                    r'<script[^>]*>.*?</script>',
                    r'javascript:',
                    r'on\w+\s*='
                ],
                'dom_based_check': True
            },
            'csrf': {
                'check_tokens': True,
                'check_referer': True,
                'check_origin': True
            },
            'rce': {
                'payloads_file': 'payloads/rce_payloads.txt',
                'command_injection_patterns': [
                    'uid=',
                    'root:x:0:0:',
                    'Directory of C:\\',
                    'bin/sh'
                ],
                'file_inclusion_check': True
            },
            'directory_bruteforce': {
                'wordlist': 'wordlists/common_dirs.txt',
                'extensions': ['.php', '.asp', '.aspx', '.jsp', '.html'],
                'status_codes': [200, 301, 302, 403],
                'max_depth': 3
            },
            'ssl': {
                'check_certificate': True,
                'check_protocols': True,
                'check_ciphers': True,
                'weak_ciphers': ['RC4', 'MD5', 'SHA1']
            },
            'reporting': {
                'template_dir': 'templates',
                'output_dir': 'reports',
                'include_screenshots': True,
                'logo_path': 'assets/logo.png'
            },
            'database': {
                'type': 'sqlite',
                'path': 'data/bug_hunter.db',
                'host': 'localhost',
                'port': 5432,
                'username': '',
                'password': '',
                'database': 'bug_hunter'
            },
            'web_interface': {
                'host': '127.0.0.1',
                'port': 5000,
                'debug': False,
                'secret_key': 'your-secret-key-change-this'
            },
            'tools': {
                'install_dir': 'tools',
                'burp_suite': {
                    'enabled': False,
                    'path': '/opt/burpsuite/burpsuite.jar'
                },
                'owasp_zap': {
                    'enabled': True,
                    'path': '/usr/share/zaproxy/zap.sh'
                },
                'nmap': {
                    'enabled': True,
                    'path': '/usr/bin/nmap'
                },
                'sqlmap': {
                    'enabled': True,
                    'path': '/usr/bin/sqlmap'
                }
            },
            'api': {
                'hackerone': {
                    'enabled': False,
                    'api_key': '',
                    'username': ''
                },
                'bugcrowd': {
                    'enabled': False,
                    'api_key': '',
                    'username': ''
                }
            },
            'logging': {
                'level': 'INFO',
                'file': 'logs/bug_hunter.log',
                'max_size': '10MB',
                'backup_count': 5
            }
        }
    
    def _save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration to file."""
        config_file = Path(self.config_path)
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            with open(config_file, 'w') as f:
                yaml.dump(config, f, default_flow_style=False, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def get_config(self) -> Dict[str, Any]:
        """Get current configuration."""
        return self.config
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """Get specific configuration section."""
        return self.config.get(section, {})
    
    def update_config(self, updates: Dict[str, Any]) -> None:
        """Update configuration with new values."""
        self._deep_update(self.config, updates)
        self._save_config(self.config)
    
    def _deep_update(self, base_dict: Dict[str, Any], update_dict: Dict[str, Any]) -> None:
        """Recursively update nested dictionaries."""
        for key, value in update_dict.items():
            if key in base_dict and isinstance(base_dict[key], dict) and isinstance(value, dict):
                self._deep_update(base_dict[key], value)
            else:
                base_dict[key] = value
    
    def reset_to_defaults(self) -> None:
        """Reset configuration to default values."""
        self.config = self._get_default_config()
        self._save_config(self.config)

