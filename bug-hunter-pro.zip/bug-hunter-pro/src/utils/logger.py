"""
Logging Configuration for Bug Hunter Pro

This module provides centralized logging configuration for the application.
"""

import logging
import sys
from pathlib import Path
from rich.console import Console
from rich.logging import RichHandler
from rich.text import Text


def setup_logger(name: str = 'BugHunterPro', verbose: bool = False, 
                 log_file: str = None) -> logging.Logger:
    """Setup and configure logger with rich formatting."""
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Console handler with rich formatting
    console = Console()
    console_handler = RichHandler(
        console=console,
        show_time=True,
        show_path=verbose,
        rich_tracebacks=True,
        markup=True
    )
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    
    # Custom formatter for console output
    console_format = "%(message)s"
    console_handler.setFormatter(logging.Formatter(console_format))
    
    logger.addHandler(console_handler)
    
    # File handler if log file specified
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(logging.DEBUG)
        
        file_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        file_handler.setFormatter(logging.Formatter(file_format))
        
        logger.addHandler(file_handler)
    
    # Suppress third-party library logs unless in verbose mode
    if not verbose:
        logging.getLogger('urllib3').setLevel(logging.WARNING)
        logging.getLogger('requests').setLevel(logging.WARNING)
        logging.getLogger('selenium').setLevel(logging.WARNING)
    
    return logger


class ColoredLogger:
    """Custom logger with colored output for different severity levels."""
    
    def __init__(self, name: str = 'BugHunterPro'):
        self.console = Console()
        self.name = name
    
    def info(self, message: str):
        """Log info message in blue."""
        self.console.print(f"[blue][INFO][/blue] {message}")
    
    def warning(self, message: str):
        """Log warning message in yellow."""
        self.console.print(f"[yellow][WARNING][/yellow] {message}")
    
    def error(self, message: str):
        """Log error message in red."""
        self.console.print(f"[red][ERROR][/red] {message}")
    
    def success(self, message: str):
        """Log success message in green."""
        self.console.print(f"[green][SUCCESS][/green] {message}")
    
    def debug(self, message: str):
        """Log debug message in dim white."""
        self.console.print(f"[dim][DEBUG][/dim] {message}")
    
    def critical(self, message: str):
        """Log critical message in bold red."""
        self.console.print(f"[bold red][CRITICAL][/bold red] {message}")
    
    def vulnerability_found(self, vuln_type: str, severity: str, target: str):
        """Log vulnerability finding with appropriate color."""
        color_map = {
            'critical': 'bold red',
            'high': 'red',
            'medium': 'yellow',
            'low': 'blue',
            'info': 'dim'
        }
        color = color_map.get(severity.lower(), 'white')
        self.console.print(f"[{color}]🔍 {vuln_type.upper()} vulnerability found ({severity.upper()}) on {target}[/{color}]")
    
    def scan_progress(self, current: int, total: int, phase: str):
        """Log scan progress."""
        percentage = (current / total) * 100 if total > 0 else 0
        self.console.print(f"[cyan]📊 Scan Progress: {current}/{total} ({percentage:.1f}%) - {phase}[/cyan]")

