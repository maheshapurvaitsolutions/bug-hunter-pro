import requests

class HTTPClient:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.session = requests.Session()
    
    def get(self, url, **kwargs):
        try:
            return self.session.get(url, timeout=30, **kwargs)
        except Exception as e:
            self.logger.error(f"HTTP GET failed: {e}")
            return None

