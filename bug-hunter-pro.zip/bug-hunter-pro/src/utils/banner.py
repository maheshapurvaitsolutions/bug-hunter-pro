"""
Banner Display Module

This module handles the display of application banners and branding.
"""

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align


def display_banner():
    """Display the Bug Hunter Pro banner."""
    console = Console()
    
    banner_text = """
    ██████╗ ██╗   ██╗ ██████╗     ██╗  ██╗██╗   ██╗███╗   ██╗████████╗███████╗██████╗ 
    ██╔══██╗██║   ██║██╔════╝     ██║  ██║██║   ██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗
    ██████╔╝██║   ██║██║  ███╗    ███████║██║   ██║██╔██╗ ██║   ██║   █████╗  ██████╔╝
    ██╔══██╗██║   ██║██║   ██║    ██╔══██║██║   ██║██║╚██╗██║   ██║   ██╔══╝  ██╔══██╗
    ██████╔╝╚██████╔╝╚██████╔╝    ██║  ██║╚██████╔╝██║ ╚████║   ██║   ███████╗██║  ██║
    ╚═════╝  ╚═════╝  ╚═════╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
                                    ██████╗ ██████╗  ██████╗ 
                                    ██╔══██╗██╔══██╗██╔═══██╗
                                    ██████╔╝██████╔╝██║   ██║
                                    ██╔═══╝ ██╔══██╗██║   ██║
                                    ██║     ██║  ██║╚██████╔╝
                                    ╚═╝     ╚═╝  ╚═╝ ╚═════╝ 
    """
    
    info_text = """
    [bold cyan]Bug Hunter Pro[/bold cyan] - [italic]Automated Vulnerability Discovery & Reporting Tool[/italic]
    
    [green]Version:[/green] 1.0.0
    [green]Author:[/green] Security Research Team
    [green]License:[/green] Educational Use Only
    
    [yellow]⚠️  WARNING: This tool is for authorized security testing only.[/yellow]
    [yellow]   Ensure you have proper permission before scanning any target.[/yellow]
    
    [blue]Features:[/blue]
    • Automated vulnerability scanning (SQL, XSS, CSRF, RCE, etc.)
    • Proof-of-Concept generation
    • Comprehensive reporting (HTML, PDF, JSON, Markdown)
    • Integration with popular security tools
    • Web-based GUI interface
    """
    
    # Display banner
    console.print("\n")
    console.print(Panel(
        Align.center(Text(banner_text, style="bold red")),
        border_style="bright_blue",
        padding=(1, 2)
    ))
    
    # Display info
    console.print(Panel(
        info_text,
        title="[bold white]Welcome to Bug Hunter Pro[/bold white]",
        border_style="green",
        padding=(1, 2)
    ))
    
    console.print("\n")


def display_scan_banner(target: str, scan_type: str):
    """Display scan initiation banner."""
    console = Console()
    
    scan_info = f"""
    [bold cyan]Target:[/bold cyan] {target}
    [bold cyan]Scan Type:[/bold cyan] {scan_type.upper()}
    [bold cyan]Status:[/bold cyan] [green]Initiating...[/green]
    """
    
    console.print(Panel(
        scan_info,
        title="[bold white]🎯 Vulnerability Scan[/bold white]",
        border_style="yellow",
        padding=(1, 2)
    ))


def display_results_summary(vulnerabilities_found: int, scan_time: float):
    """Display scan results summary."""
    console = Console()
    
    if vulnerabilities_found > 0:
        status_color = "red" if vulnerabilities_found > 5 else "yellow"
        status_icon = "⚠️" if vulnerabilities_found > 5 else "⚡"
    else:
        status_color = "green"
        status_icon = "✅"
    
    summary = f"""
    [{status_color}]Vulnerabilities Found:[/{status_color}] {vulnerabilities_found}
    [blue]Scan Duration:[/blue] {scan_time:.2f} seconds
    [blue]Status:[/blue] [{status_color}]Complete[/{status_color}] {status_icon}
    """
    
    console.print(Panel(
        summary,
        title="[bold white]📊 Scan Results[/bold white]",
        border_style=status_color,
        padding=(1, 2)
    ))

