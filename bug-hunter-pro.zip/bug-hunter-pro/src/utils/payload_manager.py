class PayloadManager:
    def __init__(self):
        self.payloads = {}
    
    def get_payloads(self, vuln_type):
        return []

