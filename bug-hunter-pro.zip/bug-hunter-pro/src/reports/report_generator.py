import os
import json
from pathlib import Path
from datetime import datetime

class ReportGenerator:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
    
    def generate_report(self, scan_results, output_dir, output_format, scan_id):
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        report_file = output_path / f"report_{scan_id}.{output_format}"
        
        if output_format == 'html':
            self._generate_html_report(scan_results, report_file)
        elif output_format == 'json':
            self._generate_json_report(scan_results, report_file)
        elif output_format == 'markdown':
            self._generate_markdown_report(scan_results, report_file)
        else:
            self._generate_text_report(scan_results, report_file)
        
        return str(report_file)
    
    def _generate_html_report(self, scan_results, report_file):
        """Generate detailed HTML report."""
        vulnerabilities = scan_results.get('vulnerabilities', [])
        target = scan_results.get('target', 'Unknown')
        scan_type = scan_results.get('scan_type', 'Unknown')
        stats = scan_results.get('statistics', {})
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Bug Hunter Pro - Vulnerability Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background-color: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .summary {{ background-color: #ecf0f1; padding: 15px; margin: 20px 0; border-radius: 5px; }}
        .vulnerability {{ border: 1px solid #bdc3c7; margin: 10px 0; padding: 15px; border-radius: 5px; }}
        .critical {{ border-left: 5px solid #e74c3c; }}
        .high {{ border-left: 5px solid #f39c12; }}
        .medium {{ border-left: 5px solid #f1c40f; }}
        .low {{ border-left: 5px solid #27ae60; }}
        .info {{ border-left: 5px solid #3498db; }}
        .vuln-title {{ font-weight: bold; font-size: 1.2em; color: #2c3e50; }}
        .vuln-details {{ margin-top: 10px; }}
        .payload {{ background-color: #f8f9fa; padding: 10px; border-radius: 3px; font-family: monospace; white-space: pre-wrap; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔍 Bug Hunter Pro - Vulnerability Report</h1>
        <p>Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="summary">
        <h2>📊 Scan Summary</h2>
        <p><strong>Target:</strong> {target}</p>
        <p><strong>Scan Type:</strong> {scan_type}</p>
        <p><strong>Vulnerabilities Found:</strong> {len(vulnerabilities)}</p>
        <p><strong>Scan Duration:</strong> {stats.get('scan_time', 0):.2f} seconds</p>
        <p><strong>Requests Sent:</strong> {stats.get('requests_sent', 0)}</p>
    </div>
    
    <h2>🚨 Vulnerabilities Found</h2>
"""
        
        if vulnerabilities:
            for i, vuln in enumerate(vulnerabilities, 1):
                severity = vuln.get('severity', 'info').lower()
                html_content += f"""
    <div class="vulnerability {severity}">
        <div class="vuln-title">{i}. {vuln.get('name', 'Unknown Vulnerability')}</div>
        <div class="vuln-details">
            <p><strong>Severity:</strong> <span style="text-transform: uppercase; font-weight: bold;">{severity}</span></p>
            <p><strong>Type:</strong> {vuln.get('type', 'Unknown')}</p>
            <p><strong>URL:</strong> {vuln.get('url', 'N/A')}</p>
            <p><strong>Parameter:</strong> {vuln.get('parameter', 'N/A')}</p>
            <p><strong>Description:</strong> {vuln.get('description', 'No description available')}</p>
            <p><strong>Impact:</strong> {vuln.get('impact', 'No impact information available')}</p>
            <p><strong>Recommendation:</strong> {vuln.get('recommendation', 'No recommendation available')}</p>
"""
                
                if vuln.get('payload'):
                    html_content += f"""
            <p><strong>Payload:</strong></p>
            <div class="payload">{vuln['payload']}</div>
"""
                
                if vuln.get('poc'):
                    html_content += f"""
            <p><strong>Proof of Concept:</strong></p>
            <div class="payload">{vuln['poc']}</div>
"""
                
                html_content += "        </div>\n    </div>\n"
        else:
            html_content += "    <p>✅ No vulnerabilities found during the scan.</p>\n"
        
        html_content += """
</body>
</html>
"""
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def _generate_json_report(self, scan_results, report_file):
        """Generate JSON report."""
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(scan_results, f, indent=2, default=str)
    
    def _generate_markdown_report(self, scan_results, report_file):
        """Generate Markdown report."""
        vulnerabilities = scan_results.get('vulnerabilities', [])
        target = scan_results.get('target', 'Unknown')
        
        markdown_content = f"""# Bug Hunter Pro - Vulnerability Report

**Target:** {target}  
**Vulnerabilities Found:** {len(vulnerabilities)}  
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Vulnerabilities

"""
        
        for i, vuln in enumerate(vulnerabilities, 1):
            markdown_content += f"""
### {i}. {vuln.get('name', 'Unknown Vulnerability')}

- **Severity:** {vuln.get('severity', 'info').upper()}
- **Type:** {vuln.get('type', 'Unknown')}
- **URL:** {vuln.get('url', 'N/A')}
- **Parameter:** {vuln.get('parameter', 'N/A')}
- **Description:** {vuln.get('description', 'No description available')}
- **Impact:** {vuln.get('impact', 'No impact information available')}
- **Recommendation:** {vuln.get('recommendation', 'No recommendation available')}

"""
            
            if vuln.get('payload'):
                markdown_content += f"**Payload:**\n```\n{vuln['payload']}\n```\n\n"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
    
    def _generate_text_report(self, scan_results, report_file):
        """Generate basic text report."""
        vulnerabilities = scan_results.get('vulnerabilities', [])
        target = scan_results.get('target', 'Unknown')
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(f"Bug Hunter Pro Scan Report\n")
            f.write(f"={'='*50}\n\n")
            f.write(f"Target: {target}\n")
            f.write(f"Vulnerabilities Found: {len(vulnerabilities)}\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            if vulnerabilities:
                f.write("Vulnerabilities:\n")
                f.write("-" * 20 + "\n\n")
                
                for i, vuln in enumerate(vulnerabilities, 1):
                    f.write(f"{i}. {vuln.get('name', 'Unknown Vulnerability')}\n")
                    f.write(f"   Severity: {vuln.get('severity', 'info').upper()}\n")
                    f.write(f"   Type: {vuln.get('type', 'Unknown')}\n")
                    f.write(f"   URL: {vuln.get('url', 'N/A')}\n")
                    f.write(f"   Parameter: {vuln.get('parameter', 'N/A')}\n")
                    f.write(f"   Description: {vuln.get('description', 'No description available')}\n")
                    if vuln.get('payload'):
                        f.write(f"   Payload: {vuln['payload']}\n")
                    f.write("\n")
            else:
                f.write("No vulnerabilities found.\n")
    
    def export_results(self, scan_results, export_format, output_path):
        return output_path

