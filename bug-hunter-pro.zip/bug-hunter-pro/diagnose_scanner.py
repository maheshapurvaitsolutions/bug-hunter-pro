#!/usr/bin/env python3
"""
Bug Hunter Pro Diagnostic Script

This script diagnoses potential issues with your Bug Hunter Pro scanner.
"""

import os
import json
import sys
from pathlib import Path

def check_dependencies():
    """Check if all required dependencies are installed"""
    print("\n[+] Checking Dependencies")
    print("="*50)
    
    required_modules = [
        'requests', 'beautifulsoup4', 'urllib3', 'yaml'
    ]
    
    missing = []
    for module in required_modules:
        try:
            __import__(module)
            print(f"✓ {module} - OK")
        except ImportError:
            print(f"✗ {module} - MISSING")
            missing.append(module)
    
    if missing:
        print(f"\n[-] Missing dependencies: {', '.join(missing)}")
        print("Install with: pip3 install --break-system-packages " + ' '.join(missing))
    else:
        print("\n[+] All dependencies are installed")

def check_config_files():
    """Check configuration files"""
    print("\n[+] Checking Configuration Files")
    print("="*50)
    
    config_files = [
        'config/default.yaml',
        'requirements.txt'
    ]
    
    for config_file in config_files:
        if os.path.exists(config_file):
            print(f"✓ {config_file} - EXISTS")
            
            # Check if YAML file is valid
            if config_file.endswith('.yaml'):
                try:
                    import yaml
                    with open(config_file, 'r') as f:
                        yaml.safe_load(f)
                    print(f"  └─ Valid YAML syntax")
                except Exception as e:
                    print(f"  └─ ✗ Invalid YAML: {e}")
        else:
            print(f"✗ {config_file} - MISSING")

def check_payload_files():
    """Check payload files"""
    print("\n[+] Checking Payload Files")
    print("="*50)
    
    payload_dir = 'payloads'
    if os.path.exists(payload_dir):
        payload_files = os.listdir(payload_dir)
        if payload_files:
            print(f"✓ Found {len(payload_files)} payload files:")
            for pf in payload_files[:5]:  # Show first 5
                print(f"  - {pf}")
        else:
            print("✗ Payload directory is empty")
    else:
        print("✗ Payloads directory missing")

def check_scanner_modules():
    """Check scanner modules"""
    print("\n[+] Checking Scanner Modules")
    print("="*50)
    
    scanner_modules = [
        'src/scanners/sql_scanner.py',
        'src/scanners/xss_scanner.py',
        'src/scanners/csrf_scanner.py',
        'src/scanners/vulnerability_scanner.py',
        'src/scanners/directory_scanner.py',
        'src/scanners/ssl_scanner.py'
    ]
    
    for module in scanner_modules:
        if os.path.exists(module):
            print(f"✓ {module} - EXISTS")
            
            # Check if module can be imported
            try:
                # Basic syntax check
                with open(module, 'r') as f:
                    compile(f.read(), module, 'exec')
                print(f"  └─ Valid Python syntax")
            except SyntaxError as e:
                print(f"  └─ ✗ Syntax error: {e}")
            except Exception as e:
                print(f"  └─ ✗ Error: {e}")
        else:
            print(f"✗ {module} - MISSING")

def test_basic_functionality():
    """Test basic scanner functionality"""
    print("\n[+] Testing Basic Functionality")
    print("="*50)
    
    try:
        # Try to import main modules
        sys.path.insert(0, 'src')
        
        from src.scanners.vulnerability_scanner import VulnerabilityScanner
        from src.utils.logger import setup_logger
        
        print("✓ Core modules can be imported")
        
        # Test logger
        logger = setup_logger()
        print("✓ Logger setup successful")
        
        # Test scanner initialization
        config = {'scanner': {}, 'sql_injection': {'error_patterns': []}}
        scanner = VulnerabilityScanner(config, logger)
        print("✓ Scanner initialization successful")
        
    except Exception as e:
        print(f"✗ Error in basic functionality: {e}")
        import traceback
        traceback.print_exc()

def check_recent_scan_results():
    """Check recent scan results"""
    print("\n[+] Checking Recent Scan Results")
    print("="*50)
    
    reports_dir = 'reports'
    if os.path.exists(reports_dir):
        report_files = [f for f in os.listdir(reports_dir) if f.endswith(('.json', '.html', '.pdf'))]
        if report_files:
            print(f"✓ Found {len(report_files)} report files:")
            
            # Check latest report
            latest_report = max(report_files, key=lambda x: os.path.getctime(f'{reports_dir}/{x}'))
            print(f"  └─ Latest: {latest_report}")
            
            # If it's JSON, check content
            if latest_report.endswith('.json'):
                try:
                    with open(f'{reports_dir}/{latest_report}', 'r') as f:
                        data = json.load(f)
                    vulns = data.get('vulnerabilities', [])
                    print(f"  └─ Contains {len(vulns)} vulnerabilities")
                except Exception as e:
                    print(f"  └─ ✗ Error reading report: {e}")
        else:
            print("⚠ No report files found - scanner may not be generating results")
    else:
        print("✗ Reports directory missing")

def suggest_fixes():
    """Suggest potential fixes"""
    print("\n[+] Potential Issues and Fixes")
    print("="*50)
    
    issues = []
    
    # Check if error patterns are configured
    if os.path.exists('config/default.yaml'):
        try:
            import yaml
            with open('config/default.yaml', 'r') as f:
                config = yaml.safe_load(f)
            
            sql_config = config.get('sql_injection', {})
            error_patterns = sql_config.get('error_patterns', [])
            
            if not error_patterns:
                issues.append("SQL injection error patterns not configured")
        except:
            issues.append("Configuration file is corrupted or invalid")
    
    # Check payload files
    if not os.path.exists('payloads') or not os.listdir('payloads'):
        issues.append("Payload files are missing or empty")
    
    if issues:
        print("⚠ Potential issues found:")
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}")
        
        print("\n🔧 Suggested fixes:")
        print("  1. Ensure error patterns are configured in config/default.yaml")
        print("  2. Add comprehensive payload files to payloads/ directory")
        print("  3. Test with a known vulnerable target first")
        print("  4. Enable verbose logging to see detailed scan progress")
        print("  5. Check network connectivity to target")
    else:
        print("✓ No obvious configuration issues found")

def main():
    print("🔍 BUG HUNTER PRO DIAGNOSTIC TOOL")
    print("="*80)
    
    # Change to script directory
    script_dir = Path(__file__).parent
    os.chdir(script_dir)
    
    check_dependencies()
    check_config_files()
    check_payload_files()
    check_scanner_modules()
    test_basic_functionality()
    check_recent_scan_results()
    suggest_fixes()
    
    print("\n" + "="*80)
    print("🎯 DIAGNOSTIC COMPLETED")
    print("="*80)

if __name__ == "__main__":
    main()

