#!/usr/bin/env python3
"""
Test script for Bug Hunter Pro Web GUI

This script demonstrates how to use the web interface programmatically.
"""

import requests
import time
import json
from rich.console import Console
from rich.table import Table

console = Console()

BASE_URL = "http://127.0.0.1:5000"

def test_web_interface():
    """Test the web interface endpoints."""
    console.print("[bold blue]Testing Bug Hunter Pro Web Interface[/bold blue]")
    
    # Test basic connectivity
    try:
        response = requests.get(f"{BASE_URL}/")
        if response.status_code == 200:
            console.print("[green]✅ Web interface is accessible[/green]")
        else:
            console.print(f"[red]❌ Web interface returned status {response.status_code}[/red]")
            return False
    except requests.ConnectionError:
        console.print("[red]❌ Could not connect to web interface. Make sure to run:[/red]")
        console.print("[yellow]python3 main.py --gui[/yellow]")
        return False
    
    # Test API endpoints
    console.print("\n[bold]Testing API endpoints:[/bold]")
    
    # Start a test scan
    scan_data = {
        "target": "httpbin.org",
        "scan_type": "quick",
        "output_format": "json"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/scan",
            json=scan_data,
            headers={'Content-Type': 'application/json'}
        )
        
        if response.status_code == 200:
            result = response.json()
            scan_id = result.get('scan_id')
            console.print(f"[green]✅ Scan started successfully: {scan_id}[/green]")
            
            # Monitor scan progress
            console.print("\n[bold]Monitoring scan progress:[/bold]")
            
            with console.status("[spinner]Running scan..."):
                while True:
                    status_response = requests.get(f"{BASE_URL}/api/scan/{scan_id}/status")
                    if status_response.status_code == 200:
                        status = status_response.json()
                        console.print(f"Progress: {status.get('progress', 0)}% - Status: {status.get('status', 'unknown')}")
                        
                        if status.get('status') in ['completed', 'failed']:
                            break
                    
                    time.sleep(2)
            
            if status.get('status') == 'completed':
                console.print("[green]✅ Scan completed successfully![/green]")
                
                # Get results
                results_response = requests.get(f"{BASE_URL}/api/results/{scan_id}")
                if results_response.status_code == 200:
                    results = results_response.json()
                    console.print(f"\n[bold]Scan Results for {results.get('target', 'unknown')}:[/bold]")
                    
                    # Create results table
                    table = Table()
                    table.add_column("Property", style="cyan")
                    table.add_column("Value", style="green")
                    
                    table.add_row("Target", str(results.get('target', 'N/A')))
                    table.add_row("Scan Type", str(results.get('scan_type', 'N/A')))
                    table.add_row("Status", str(results.get('status', 'N/A')))
                    table.add_row("Start Time", str(results.get('start_time', 'N/A')))
                    table.add_row("End Time", str(results.get('end_time', 'N/A')))
                    
                    # Check for vulnerabilities in results
                    scan_results = results.get('results', {})
                    vulnerabilities = scan_results.get('vulnerabilities', [])
                    table.add_row("Vulnerabilities Found", str(len(vulnerabilities)))
                    
                    console.print(table)
                    
                    if vulnerabilities:
                        console.print("\n[bold red]Vulnerabilities detected:[/bold red]")
                        for i, vuln in enumerate(vulnerabilities, 1):
                            console.print(f"{i}. {vuln.get('type', 'Unknown')} - {vuln.get('severity', 'Unknown')}")
                    else:
                        console.print("\n[green]No vulnerabilities detected.[/green]")
            else:
                console.print(f"[red]❌ Scan failed: {status.get('error', 'Unknown error')}[/red]")
                
        else:
            console.print(f"[red]❌ Failed to start scan: {response.status_code}[/red]")
            console.print(response.text)
            
    except Exception as e:
        console.print(f"[red]❌ Error testing API: {str(e)}[/red]")
        return False
    
    return True

def show_gui_usage():
    """Show how to use the web GUI."""
    console.print("\n[bold blue]How to use Bug Hunter Pro Web GUI:[/bold blue]")
    
    steps = [
        "1. Start the web interface: [yellow]python3 main.py --gui[/yellow]",
        "2. Open your browser and go to: [yellow]http://127.0.0.1:5000[/yellow]",
        "3. Navigate to [green]'New Scan'[/green] to start a vulnerability assessment",
        "4. Enter a target URL (try [cyan]httpbin.org[/cyan] for testing)",
        "5. Select scan type and output format",
        "6. Click [green]'Start Scan'[/green] and monitor progress",
        "7. View results in the [green]'Results'[/green] section",
        "8. Check configuration in [green]'Configuration'[/green] page"
    ]
    
    for step in steps:
        console.print(f"   {step}")
    
    console.print("\n[bold]Available pages:[/bold]")
    pages = [
        ("Dashboard", "/", "Overview of scans and statistics"),
        ("New Scan", "/scan", "Start a new vulnerability scan"),
        ("Results", "/results", "View completed scan results"),
        ("Configuration", "/config", "View and modify settings"),
        ("About", "/about", "Information about Bug Hunter Pro")
    ]
    
    page_table = Table()
    page_table.add_column("Page", style="cyan")
    page_table.add_column("URL", style="yellow")
    page_table.add_column("Description", style="green")
    
    for name, url, desc in pages:
        page_table.add_row(name, f"http://127.0.0.1:5000{url}", desc)
    
    console.print(page_table)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Test Bug Hunter Pro Web GUI")
    parser.add_argument("--test", action="store_true", help="Run API tests")
    parser.add_argument("--usage", action="store_true", help="Show usage instructions")
    
    args = parser.parse_args()
    
    if args.test:
        test_web_interface()
    elif args.usage:
        show_gui_usage()
    else:
        console.print("[bold]Bug Hunter Pro Web GUI Tester[/bold]")
        console.print("Use --test to run API tests or --usage for instructions")
        show_gui_usage()

