#!/bin/bash

# Bug Hunter Pro Installation Script
# This script sets up Bug Hunter Pro with all necessary dependencies

set -e

echo "========================================"
echo "    Bug Hunter Pro Installation"
echo "========================================"
echo

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_warning "This script should not be run as root for security reasons."
   print_warning "Please run as a regular user with sudo privileges."
   exit 1
fi

# Check if Python 3.8+ is installed
print_status "Checking Python version..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
    REQUIRED_VERSION="3.8"
    
    if python3 -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)"; then
        print_success "Python $PYTHON_VERSION found (>= $REQUIRED_VERSION required)"
    else
        print_error "Python $REQUIRED_VERSION or higher is required. Found: $PYTHON_VERSION"
        exit 1
    fi
else
    print_error "Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Check if pip is installed
print_status "Checking pip installation..."
if command -v pip3 &> /dev/null; then
    print_success "pip3 found"
else
    print_error "pip3 is not installed. Please install pip3."
    exit 1
fi

# Create virtual environment
print_status "Creating virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    print_success "Virtual environment created"
else
    print_warning "Virtual environment already exists"
fi

# Activate virtual environment
print_status "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
print_status "Upgrading pip..."
pip install --upgrade pip

# Install Python dependencies
print_status "Installing Python dependencies..."
pip install -r requirements.txt
print_success "Python dependencies installed"

# Create necessary directories
print_status "Creating project directories..."
mkdir -p {config,logs,data,wordlists,templates,assets}
print_success "Project directories created"

# Install system dependencies (optional)
if command -v apt-get &> /dev/null; then
    print_status "Detected Debian/Ubuntu system. Installing system dependencies..."
    
    # Check if nmap is installed
    if ! command -v nmap &> /dev/null; then
        print_status "Installing nmap..."
        sudo apt-get update
        sudo apt-get install -y nmap
    fi
    
    # Check if sqlmap is installed
    if ! command -v sqlmap &> /dev/null; then
        print_status "Installing sqlmap..."
        sudo apt-get install -y sqlmap
    fi
    
else
    print_warning "Non-Debian system detected. Please manually install: nmap, sqlmap"
fi

# Create sample configuration
print_status "Creating default configuration..."
python3 -c "
from src.utils.config_manager import ConfigManager
config_manager = ConfigManager()
print('Default configuration created at: config/default.yaml')
" 2>/dev/null || print_warning "Could not create default config automatically"

# Set permissions
print_status "Setting file permissions..."
chmod +x main.py
chmod +x install.sh

# Create symlink for easy access
print_status "Creating command line alias..."
if [ ! -f "/usr/local/bin/bug-hunter-pro" ]; then
    echo "#!/bin/bash" > bug-hunter-pro
    echo "cd $(pwd) && python3 main.py \"\$@\"" >> bug-hunter-pro
    chmod +x bug-hunter-pro
    sudo mv bug-hunter-pro /usr/local/bin/
    print_success "Created 'bug-hunter-pro' command for system-wide access"
fi

print_success "Installation completed successfully!"
echo
echo "========================================"
echo "           Quick Start Guide"
echo "========================================"
echo
echo "1. Activate virtual environment:"
echo "   source venv/bin/activate"
echo
echo "2. Run Bug Hunter Pro:"
echo "   python3 main.py --help"
echo
echo "3. Quick scan example:"
echo "   python3 main.py -t https://example.com"
echo
echo "4. Launch web interface:"
echo "   python3 main.py --gui"
echo
echo "5. Install additional tools:"
echo "   python3 main.py --install-tools"
echo
echo "========================================"
echo "⚠️  IMPORTANT SECURITY NOTICE"
echo "========================================"
echo "This tool is for authorized security testing only."
echo "Ensure you have permission before scanning any target."
echo "Unauthorized scanning is illegal and unethical."
echo "========================================"
echo

